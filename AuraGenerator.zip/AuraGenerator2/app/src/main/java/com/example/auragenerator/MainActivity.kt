package com.example.auragenerator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val neonBtn = findViewById<Button>(R.id.neonBtn)
        val rainBtn = findViewById<Button>(R.id.rainBtn)
        val moonBtn = findViewById<Button>(R.id.moonBtn)
        val chaosBtn = findViewById<Button>(R.id.chaosBtn)
        val silenceBtn = findViewById<Button>(R.id.silenceBtn)
        val generateBtn = findViewById<Button>(R.id.generateBtn)

        resultText = findViewById(R.id.resultText)

        neonBtn.setOnClickListener {
            resultText.text = "Cyberpunk Dreamwalker ✨"
        }

        rainBtn.setOnClickListener {
            resultText.text = "Rainy Café Philosopher 🌧"
        }

        moonBtn.setOnClickListener {
            resultText.text = "Midnight Overthinker 🌙"
        }

        chaosBtn.setOnClickListener {
            resultText.text = "Chaotic Luxury Energy ⚡"
        }

        silenceBtn.setOnClickListener {
            resultText.text = "Silent Observer of the Universe 🖤"
        }

        generateBtn.setOnClickListener {
            val auraList = listOf(
                "Velvet Night Soul 🌌",
                "Digital Mystic ✨",
                "Neon Heart Wanderer 💜",
                "Celestial Chaos Entity ⚡",
                "Lost Romantic in a Futuristic City 🌃"
            )

            resultText.text = auraList.random()
        }
    }
}