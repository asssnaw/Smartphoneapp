package com.example.glowuptracker

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val saveBtn = findViewById<Button>(R.id.saveBtn)
        val savedText = findViewById<TextView>(R.id.savedText)
        val backBtn = findViewById<Button>(R.id.backBtn)

        val sharedPreferences: SharedPreferences =
            getSharedPreferences("GlowPrefs", MODE_PRIVATE)

        val savedName = sharedPreferences.getString("username", "")

        savedText.text = "Saved Name: $savedName"

        saveBtn.setOnClickListener {

            val name = nameInput.text.toString()

            val editor = sharedPreferences.edit()

            editor.putString("username", name)

            editor.apply()

            savedText.text = "Saved Name: $name"
        }

        backBtn.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}