package com.example.glowuptracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MotivationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_motivation)

        val motivationText = findViewById<TextView>(R.id.motivationText)
        val generateBtn = findViewById<Button>(R.id.generateMotivationBtn)
        val backBtn = findViewById<Button>(R.id.backBtn)

        generateBtn.setOnClickListener {

            backBtn.setOnClickListener {
                startActivity(Intent(this, MainActivity::class.java))
            }

            val quotes = listOf(
                "Your future self is watching you right now ✨",
                "Small progress is still progress 🌱",
                "Discipline creates confidence 💪",
                "Glow differently this year 🌟",
                "You are becoming the person you dreamed of 💫"
            )

            motivationText.text = quotes.random()
        }
    }
}