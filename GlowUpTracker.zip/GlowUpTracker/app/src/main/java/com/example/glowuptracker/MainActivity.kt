package com.example.glowuptracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val motivationBtn = findViewById<Button>(R.id.motivationBtn)
        val settingsBtn = findViewById<Button>(R.id.settingsBtn)

        motivationBtn.setOnClickListener {
            startActivity(Intent(this, MotivationActivity::class.java))
        }

        settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}